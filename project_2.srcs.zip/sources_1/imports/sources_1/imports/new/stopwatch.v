`timescale 1ns / 1ps
module stopwatch (
    input        clk,
    input        rst,
    input        sw_0,
    input        Btn_L,
    input        Btn_R,
    output [3:0] fnd_com,
    output [7:0] fnd
);

    wire [6:0] w_msec;
    wire [5:0] w_sec;
    wire [5:0] w_min;
    wire [4:0] w_hour;
    wire w_runstop, w_clear;
    wire w_btn_r, w_btn_l;

    fnd_controller u_fnd_controller (
        .clk(clk),
        .reset(rst),
        .sw0(sw_0),
        .i_time({w_hour, w_min, w_sec, w_msec}),
        .fnd_com(fnd_com),
        .fnd(fnd)
    );

    stopwatch_cu u_stopwatch_cu (
        .clk(clk),
        .rst(rst),
        .in_runstop(w_btn_r),
        .in_clear(w_btn_l),
        .out_runstop(w_runstop),
        .out_clear(w_clear)
    );

    stopwatch_dp u_stopwatch_dp (
        .clk(clk),
        .rst(rst),
        .i_runstop(w_runstop),
        .i_clear(w_clear),
        .msec(w_msec),
        .sec(w_sec),
        .min(w_min),
        .hour(w_hour)
    );

    button_debounce u_button_debounce_R (
        .clk  (clk),
        .rst  (rst),
        .i_btn(Btn_R),
        .o_btn(w_btn_r)
    );

    button_debounce u_button_debounce_L (
        .clk  (clk),
        .rst  (rst),
        .i_btn(Btn_L),
        .o_btn(w_btn_l)
    );

endmodule
