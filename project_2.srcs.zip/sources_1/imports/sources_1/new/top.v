`timescale 1ns / 1ps

module top (
    input        clk,
    input        rst,
    input        Btn_L,
    input        Btn_U,
    input        Btn_D,
    input        Btn_R,
    input        sw0,
    input        sw1,
    input        Rx,
    output       Tx,
    output [7:0] fnd,
    output [3:0] fnd_com,
    output [3:0] led
);
    wire cmd_runstop_w;
    wire cmd_clear_w;

    wire Btn_L_or = Btn_L | cmd_clear_w;
    wire Btn_R_or = Btn_R | cmd_runstop_w;

    uart_top u_uart_top(
        .clk    (clk),
        .rst    (rst),
        .rx     (Rx),
        .runstop(cmd_runstop_w),
        .clear  (cmd_clear_w),
        .tx     (Tx)
    );

    // 시계/스톱워치 UI
    clock_top u_clock_top(
        .clk        (clk),
        .rst        (rst),
        .sw0        (sw0),
        .sw1        (sw1),
        .Btn_L      (Btn_L_or),
        .Btn_U      (Btn_U),
        .Btn_D      (Btn_D),
        .Btn_R      (Btn_R_or),
        .led        (led),
        .fnd_com    (fnd_com),
        .fnd        (fnd)
    );
endmodule
