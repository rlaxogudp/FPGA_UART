`timescale 1ns / 1ps

module watch (
    input        clk,
    input        rst,
    input        sw0,
    input        Btn_L,
    input        Btn_U,
    input        Btn_D,
    output [3:0] fnd_com,
    output [7:0] fnd
);

    wire [6:0] w_msec;
    wire [5:0] w_sec;
    wire [5:0] w_min;
    wire [4:0] w_hour;
    wire w_btn_u, w_btn_d, w_btn_l;

    watch_dp u_watch_dp (
        .clk(clk),
        .rst(rst),
        .up_sec(w_btn_d),
        .up_min(w_btn_u),
        .up_hour(w_btn_l),
        .msec(w_msec),
        .sec(w_sec),
        .min(w_min),
        .hour(w_hour)
    );

    fnd_controller u_fnd_controller (
        .clk(clk),
        .reset(rst),
        .sw0(sw0),
        .i_time({w_hour, w_min, w_sec, w_msec}),
        .fnd_com(fnd_com),
        .fnd(fnd)
    );

    button_debounce u_button_debounce_U (
        .clk  (clk),
        .rst  (rst),
        .i_btn(Btn_U),
        .o_btn(w_btn_u)
    );

    button_debounce u_button_debounce_D (
        .clk  (clk),
        .rst  (rst),
        .i_btn(Btn_D),
        .o_btn(w_btn_d)
    );

    button_debounce u_button_debounce_L (
        .clk  (clk),
        .rst  (rst),
        .i_btn(Btn_L),
        .o_btn(w_btn_l)
    );

endmodule