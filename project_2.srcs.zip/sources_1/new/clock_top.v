`timescale 1ns / 1ps

module clock_top (
    input        clk,
    input        rst,
    input        sw0,
    input        sw1,
    input        Btn_L,
    input        Btn_U,
    input        Btn_D,
    input        Btn_R,
    output [3:0] led,
    output [3:0] fnd_com,
    output [7:0] fnd
);
    wire [3:0] sw_fnd_com, watch_fnd_com;
    wire [7:0] sw_fnd, watch_fnd;


    stopwatch u_stopwatch (
        .clk    (clk),
        .rst    (rst),
        .sw_0   (sw0),
        .Btn_L  (Btn_L),
        .Btn_R  (Btn_R),
        .fnd_com(sw_fnd_com),
        .fnd    (sw_fnd)
    );


    watch u_watch (
        .clk    (clk),
        .rst    (rst),
        .sw0    (sw0),
        .Btn_L  (Btn_L),
        .Btn_U  (Btn_U),
        .Btn_D  (Btn_D),
        .fnd_com(watch_fnd_com),
        .fnd    (watch_fnd)
    );

    led u_led (
        .sw0(sw0),
        .sw1(sw1),
        .led(led)
    );

    assign fnd_com = (sw1 == 1'b0) ? sw_fnd_com : watch_fnd_com;
    assign fnd = (sw1 == 1'b0) ? sw_fnd : watch_fnd;


endmodule


module led(
    input  sw0,
    input  sw1,
    output [3:0] led
);

    assign led = (sw1==0 && sw0==0) ? 4'b0001 :
                 (sw1==0 && sw0==1) ? 4'b0010 :
                 (sw1==1 && sw0==0) ? 4'b0100 :
                                       4'b1000 ;
endmodule