`timescale 1ns / 1ps

module command_cu (
    input        clk,
    input        rst,
    input  [7:0] rx_fifo_data,
    input        rx_trigger,
    output       runstop,
    output       clear
);

    reg runstop_reg, runstop_next;
    reg clear_reg, clear_next;
    
    assign runstop = runstop_reg;
    assign clear   = clear_reg;

    always @(posedge clk, posedge rst) begin
        if (rst) begin
            runstop_reg <= 1'b0;
            clear_reg   <= 1'b0;
        end else begin
            runstop_reg <= runstop_next;
            clear_reg   <= clear_next;
        end
    end

    always @(*) begin
        runstop_next = 1'b0;
        clear_next   = 1'b0;
        if (rx_trigger) begin
            case (rx_fifo_data)
                8'h52: begin
                    runstop_next = 1'b1;
                end
                8'h53: begin
                    runstop_next = 1'b1;
                end
                8'h43: begin
                    clear_next = 1'b1;
                end
            endcase
        end
    end
endmodule
